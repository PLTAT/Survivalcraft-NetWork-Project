using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using dnlib.DotNet;
using dnlib.DotNet.Emit;

[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows = true)]
[assembly: Debuggable(DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.DisableOptimizations | DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | DebuggableAttribute.DebuggingModes.EnableEditAndContinue)]
[assembly: AssemblyVersion("0.0.0.0")]
namespace ConsoleApplication
{
internal static class Program
{
	private static void Main(string[] args)
	{
		if (args.Length < 2 || args[0] == "help")
		{
			Console.WriteLine("Usage:");
			Console.WriteLine("mono StringTool.exe extract assembly.dll");
			Console.WriteLine("mono StringTool.exe retrieve assembly.dll");
			return;
		}
		ModuleDefMD moduleDefMD = ModuleDefMD.Load(args[1]);
		List<Instruction> list = (from i in (from m in moduleDefMD.GetTypes().SelectMany((TypeDef t) => t.Methods)
				where m.Body != null
				select m).SelectMany((MethodDef m) => m.Body.Instructions)
			where i.OpCode == OpCodes.Ldstr
			where IsChinese(i.Operand as string)
			select i).ToList();
		if (args[0] == "extract")
		{
			using StreamWriter streamWriter = new StreamWriter("strings.txt");
			foreach (Instruction item in list)
			{
				streamWriter.WriteLine((item.Operand as string).Replace("\n", "\\n"));
			}
		}
		else if (args[0] == "retrieve")
		{
			string[] array = File.ReadAllLines("strings.txt");
			string[] array2 = new string[0];
			if (File.Exists("replaces.txt"))
			{
				array2 = File.ReadAllLines("replaces.txt").ToArray();
			}
			for (int j = 0; j < list.Count; j++)
			{
				string text = array[j];
				string[] array3 = array2;
				string[] array4 = array3;
				foreach (string text2 in array4)
				{
					string[] array5 = text2.Replace(" : ", "∆").Split('∆');
					if (text == array5[0])
					{
						text = array5[1];
					}
				}
				list[j].Operand = text;
			}
		}
		MemoryStream memoryStream = new MemoryStream();
		moduleDefMD.Write(memoryStream);
		File.WriteAllBytes(args[1], memoryStream.ToArray());
	}

	private static bool IsChinese(string str)
	{
		if (string.IsNullOrEmpty(str))
		{
			return false;
		}
		return str.Any((char c) => c >= '一' && c <= '\u9fff');
	}
}
}